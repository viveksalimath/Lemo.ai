---
name: 📝 Documentation
about: Are the docs missing, confusing, etc.? Tell us more about it.
---

<!--
Thanks for your interest in Leon! ❤️
If it is related to https://docs.getleon.ai, please open an issue there: https://github.com/leon-ai/docs.getleon.ai/issues.
Please check if there is no similar issue before creating this one.

Please place an x (no spaces - [x]) in all [ ] that apply.
-->

### Documentation Is:

- [ ] Missing
- [ ] Needed
- [ ] Confusing
- [ ] Not Sure?

### Explanation

### Proposal
