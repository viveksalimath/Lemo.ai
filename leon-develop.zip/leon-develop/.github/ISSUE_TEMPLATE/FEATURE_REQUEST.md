---
name: ✨ Feature Request
about: Suggest a new feature idea.
labels: feature request
---

<!--
Thanks for your interest in Leon! ❤️
Please check if there is no similar issue before creating this one.
-->

### Feature Use Case

### Feature Proposal
