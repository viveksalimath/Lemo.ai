---
name: 🔧 Improvement
about: Suggest an idea which is not a feature.
labels: improvement
---

<!--
Thanks for your interest in Leon! ❤️
Please check if there is no similar issue before creating this one.
-->

### Expected Behavior

### Actual Behavior

### Proposal
