---
name: ❓ Question
about: Ask a question about Leon.
labels: question
---

<!--
Thanks for your interest in Leon! ❤️
Please check if there is no similar issue before creating this one.

Please ask one question per issue.
-->

### Question
