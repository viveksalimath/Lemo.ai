import { type FlexboxProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Flexbox extends WidgetComponent<FlexboxProps> {
  constructor(props: FlexboxProps) {
    super(props)
  }
}
