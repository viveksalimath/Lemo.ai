import { type FormProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Form extends WidgetComponent<FormProps> {
  constructor(props: FormProps) {
    super(props)
  }
}
