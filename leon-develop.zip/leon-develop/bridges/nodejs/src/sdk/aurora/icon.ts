import { type IconProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Icon extends WidgetComponent<IconProps> {
  constructor(props: IconProps) {
    super(props)
  }
}
