import { type InputProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Input extends WidgetComponent<InputProps> {
  constructor(props: InputProps) {
    super(props)
  }
}
