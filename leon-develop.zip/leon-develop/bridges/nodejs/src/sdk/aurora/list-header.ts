import { type ListHeaderProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class ListHeader extends WidgetComponent<ListHeaderProps> {
  constructor(props: ListHeaderProps) {
    super(props)
  }
}
