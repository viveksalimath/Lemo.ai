import { type ListItemProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class ListItem extends WidgetComponent<ListItemProps> {
  constructor(props: ListItemProps) {
    super(props)
  }
}
