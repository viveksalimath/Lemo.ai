import { type ListProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class List extends WidgetComponent<ListProps> {
  constructor(props: ListProps) {
    super(props)
  }
}
