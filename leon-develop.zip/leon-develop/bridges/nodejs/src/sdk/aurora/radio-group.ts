import { type RadioGroupProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class RadioGroup extends WidgetComponent<RadioGroupProps> {
  constructor(props: RadioGroupProps) {
    super(props)
  }
}
