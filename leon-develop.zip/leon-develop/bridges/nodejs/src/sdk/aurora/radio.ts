import { type RadioProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Radio extends WidgetComponent<RadioProps> {
  constructor(props: RadioProps) {
    super(props)
  }
}
