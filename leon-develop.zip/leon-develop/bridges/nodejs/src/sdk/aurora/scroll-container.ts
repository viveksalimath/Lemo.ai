import { type ScrollContainerProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class ScrollContainer extends WidgetComponent<ScrollContainerProps> {
  constructor(props: ScrollContainerProps) {
    super(props)
  }
}
