import { type SelectOptionProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class SelectOption extends WidgetComponent<SelectOptionProps> {
  constructor(props: SelectOptionProps) {
    super(props)
  }
}
