import { type TabContentProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class TabContent extends WidgetComponent<TabContentProps> {
  constructor(props: TabContentProps) {
    super(props)
  }
}
