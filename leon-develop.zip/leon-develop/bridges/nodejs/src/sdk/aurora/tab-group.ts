import { type TabGroupProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class TabGroup extends WidgetComponent<TabGroupProps> {
  constructor(props: TabGroupProps) {
    super(props)
  }
}
