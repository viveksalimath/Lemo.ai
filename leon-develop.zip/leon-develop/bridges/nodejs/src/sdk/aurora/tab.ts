import { type TabProps } from '@leon-ai/aurora'

import { WidgetComponent } from '../widget-component'

export class Tab extends WidgetComponent<TabProps> {
  constructor(props: TabProps) {
    super(props)
  }
}
