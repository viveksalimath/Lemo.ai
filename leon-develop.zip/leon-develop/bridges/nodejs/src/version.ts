export const VERSION = '1.2.0'
