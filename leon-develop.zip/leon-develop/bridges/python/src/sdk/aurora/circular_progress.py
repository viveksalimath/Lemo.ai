from ..widget_component import WidgetComponent


class CircularProgress(WidgetComponent[dict]):
    def __init__(self, props: dict):
        super().__init__(props)
