console.info('\x1b[36m➡ %s\x1b[0m', "Running Leon's installation...")
