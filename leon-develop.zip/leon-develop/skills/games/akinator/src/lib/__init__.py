from .main import Akinator,AkinatorError
__version__      = '1.6.0'
__url__          = 'https://github.com/taka-4602/Akinator-python'
