export const ONE_DAY_MILLISECONDS = 1_000 * 60 * 60 * 24
